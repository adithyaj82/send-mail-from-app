Send email from app
==============================

How to send an email from an app in Swift.

Tutorial:

http://www.seemuapps.com/swift-send-email-from-app

https://www.youtube.com/watch?v=fiFRxD0QQnY

Check out our Website: http://www.seemuapps.com

Follow us on Twtitter: https://twitter.com/SeemuApps

Like us on Facebook: https://www.facebook.com/SeemuApps
